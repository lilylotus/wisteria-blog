#!/usr/bin/env bash
#
# setup-pxe-server.sh —— Debian 11/12/13 网络自动安装服务器一键部署
#
# 组件: dnsmasq (TFTP + proxyDHCP/DHCP)  +  nginx (HTTP 提供 preseed)
# 支持: BIOS (pxelinux) 与 UEFI (grub) 客户端
#
# 用法:
#   sudo ./setup-pxe-server.sh              安装并配置
#   sudo ./setup-pxe-server.sh update       仅重新渲染 preseed/启动菜单/配置(改完参数后用)
#   sudo ./setup-pxe-server.sh uninstall    移除配置并停止 dnsmasq (加 --purge 同时删除文件)
#
# 参数通过环境变量或同目录的 config.env 设置,见 config.env.example
#
set -Eeuo pipefail
trap 'echo "[ERROR] 第 ${LINENO} 行出错: ${BASH_COMMAND}" >&2' ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${SCRIPT_DIR}/config.env" ]]; then
  # shellcheck disable=SC1091
  source "${SCRIPT_DIR}/config.env"
fi

# ----------------------------- 可调参数 --------------------------------------
: "${MODE:=proxy}"                      # proxy=与现有 DHCP 共存(推荐) | dhcp=本机提供完整 DHCP
: "${IFACE:=}"                          # 监听网卡,留空自动识别
: "${SERVER_IP:=}"                      # 本机 IP,留空自动识别
: "${ALLOW_CIDR:=}"                     # 允许访问 preseed 的网段,留空=本机所在网段

# MODE=dhcp 时需要
: "${DHCP_START:=}"
: "${DHCP_END:=}"
: "${DHCP_LEASE:=12h}"
: "${GATEWAY:=}"
: "${DNS_SERVER:=}"

: "${HTTP_PORT:=8080}"
: "${TFTP_ROOT:=/srv/tftp}"
: "${WEB_ROOT:=/var/www/debian13-preseed}"

: "${DEBIAN_MIRROR:=deb.debian.org}"    # 国内可用 mirrors.tuna.tsinghua.edu.cn
: "${MIRROR_DIR:=/debian}"
: "${DEBIAN_RELEASE:=13}"                # 要安装的版本: 13(trixie) | 12(bookworm) | 11(bullseye)
: "${NETBOOT_URL:=}"                     # 留空=按版本自动生成
: "${FORCE_DOWNLOAD:=0}"

# 被安装系统的参数
: "${TARGET_HOSTNAME:=debian}"
: "${TARGET_DOMAIN:=localdomain}"
: "${TARGET_USER:=admin}"
: "${TARGET_PASSWORD:=}"                # 留空=随机生成(保存到 CRED_FILE)
: "${TARGET_DISK:=}"                    # 留空=自动选第一块磁盘,例如 /dev/sda
: "${TIMEZONE:=Asia/Shanghai}"
: "${LOCALE:=en_US.UTF-8}"
: "${EXTRA_PACKAGES:=sudo curl wget vim htop ca-certificates qemu-guest-agent}"
: "${SSH_PUBKEY_FILE:=}"                # 可选: 写入新系统用户的 authorized_keys

# 启动菜单
: "${DEFAULT_ENTRY:=install}"           # install | manual | local
: "${MENU_TIMEOUT:=10}"                 # 秒

CRED_FILE="/root/debian13-netinstall-credentials.txt"
DNSMASQ_CONF="/etc/dnsmasq.d/debian13-pxe.conf"
NGINX_CONF="/etc/nginx/conf.d/debian13-preseed.conf"
EFI_BIN=""
GENERATED_PW=0
DEB_VER=""
DEB_SUITE=""

# ----------------------------- 工具函数 --------------------------------------
log()  { printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

need_root() { [[ $EUID -eq 0 ]] || die "请使用 root 运行: sudo $0 ${*:-}"; }

usage() {
  sed -n '2,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

resolve_release() {
  case "${DEBIAN_RELEASE,,}" in
    13|trixie)   DEB_VER=13; DEB_SUITE=trixie ;;
    12|bookworm) DEB_VER=12; DEB_SUITE=bookworm ;;
    11|bullseye) DEB_VER=11; DEB_SUITE=bullseye ;;
    *) die "DEBIAN_RELEASE 只支持 13|12|11 (或 trixie|bookworm|bullseye)" ;;
  esac
  if [[ -z "$NETBOOT_URL" ]]; then
    NETBOOT_URL="http://${DEBIAN_MIRROR}${MIRROR_DIR}/dists/${DEB_SUITE}/main/installer-amd64/current/images/netboot/netboot.tar.gz"
  fi
  if [[ "$DEB_VER" == "11" ]]; then
    warn "Debian 11 已结束 LTS 支持,官方镜像可能已移至 archive.debian.org;如下载失败请设置 DEBIAN_MIRROR=archive.debian.org"
  fi
}

validate_mode() {
  resolve_release
  case "$MODE" in
    proxy) ;;
    dhcp)
      [[ -n "$DHCP_START" && -n "$DHCP_END" ]] \
        || die "MODE=dhcp 需要设置 DHCP_START 和 DHCP_END,例如 DHCP_START=192.168.1.100 DHCP_END=192.168.1.200"
      ;;
    *) die "MODE 只能是 proxy 或 dhcp" ;;
  esac
  case "$DEFAULT_ENTRY" in install|manual|local) ;; *) die "DEFAULT_ENTRY 只能是 install|manual|local" ;; esac
}

detect_network() {
  command -v ip >/dev/null || die "缺少 ip 命令 (iproute2)"
  if [[ -z "$IFACE" ]]; then
    IFACE="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
  fi
  [[ -n "$IFACE" ]] || die "无法自动识别网卡,请设置 IFACE=eth0"

  if [[ -z "$SERVER_IP" ]]; then
    SERVER_IP="$(ip -4 -o addr show dev "$IFACE" scope global | awk 'NR==1{sub("/.*","",$4); print $4}')"
  fi
  [[ -n "$SERVER_IP" ]] || die "网卡 ${IFACE} 没有 IPv4 地址,请设置 SERVER_IP"

  if [[ -z "$ALLOW_CIDR" ]]; then
    ALLOW_CIDR="$(ip -4 route show dev "$IFACE" proto kernel scope link | awk 'NR==1{print $1}')"
  fi
  if [[ -z "$GATEWAY" ]]; then
    GATEWAY="$(ip -4 route show default dev "$IFACE" | awk 'NR==1{print $3}')"
  fi
  : "${DNS_SERVER:=$GATEWAY}"
}

# ----------------------------- 安装依赖 --------------------------------------
install_packages() {
  log "安装依赖: dnsmasq nginx curl openssl ..."
  export DEBIAN_FRONTEND=noninteractive
  local made_policy=0
  # 安装期间禁止自动启动服务(默认 dnsmasq 会尝试占用 53 端口,与 systemd-resolved 冲突)
  if [[ ! -e /usr/sbin/policy-rc.d ]]; then
    printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d
    chmod +x /usr/sbin/policy-rc.d
    made_policy=1
  fi
  if ! { apt-get update -qq && \
         apt-get install -y --no-install-recommends \
           dnsmasq nginx curl ca-certificates openssl iproute2 tar gzip; }; then
    [[ $made_policy -eq 1 ]] && rm -f /usr/sbin/policy-rc.d
    die "依赖安装失败"
  fi
  [[ $made_policy -eq 1 ]] && rm -f /usr/sbin/policy-rc.d
  return 0
}

# ----------------------------- netboot 文件 ----------------------------------
link_if_missing() {
  local name="$1" src
  [[ -e "${TFTP_ROOT}/${name}" ]] && return 0
  src="$(find "$TFTP_ROOT" -name "$name" -print -quit 2>/dev/null || true)"
  if [[ -n "$src" ]]; then
    ln -sf "${src#"${TFTP_ROOT}/"}" "${TFTP_ROOT}/${name}"
  else
    warn "netboot 中未找到 ${name}"
  fi
  return 0
}

fetch_netboot() {
  mkdir -p "$TFTP_ROOT"
  local marker="${TFTP_ROOT}/.netboot-suite" cur=""
  if [[ -f "$marker" ]]; then
    cur="$(cat "$marker")"
  elif [[ -f "${TFTP_ROOT}/debian-installer/amd64/linux" ]]; then
    cur="trixie"   # 旧版脚本部署的目录没有标记文件,当时只支持 trixie
  fi

  if [[ -f "${TFTP_ROOT}/debian-installer/amd64/linux" && "$FORCE_DOWNLOAD" != "1" && "$cur" == "$DEB_SUITE" ]]; then
    log "netboot (${DEB_SUITE}) 已存在,跳过下载 (FORCE_DOWNLOAD=1 可强制刷新)"
  else
    [[ -n "$cur" && "$cur" != "$DEB_SUITE" ]] && log "版本切换: ${cur} -> ${DEB_SUITE},将替换 netboot 文件"
    log "下载 netboot: ${NETBOOT_URL}"
    local tmp; tmp="$(mktemp)"
    if ! curl -fL --retry 3 --connect-timeout 15 -o "$tmp" "$NETBOOT_URL"; then
      rm -f "$tmp"
      die "下载失败。可尝试 DEBIAN_MIRROR=mirrors.tuna.tsinghua.edu.cn 重新运行"
    fi
    # 下载成功后才清理旧文件,避免失败时把可用的旧版本也删掉
    rm -rf "${TFTP_ROOT:?}/debian-installer"
    find "$TFTP_ROOT" -maxdepth 1 -type l -delete
    tar -xzf "$tmp" -C "$TFTP_ROOT"
    rm -f "$tmp"
    echo "$DEB_SUITE" > "$marker"
  fi
  link_if_missing pxelinux.0
  link_if_missing ldlinux.c32
  [[ -f "${TFTP_ROOT}/debian-installer/amd64/linux" ]] \
    || die "netboot 内容不完整: 缺少 debian-installer/amd64/linux"
  chmod -R a+rX "$TFTP_ROOT"
}

# UEFI 引导链: bootnetx64.efi (shim) -> grubx64.efi (grub) -> grub/grub.cfg
# proxyDHCP 下 shim 无法得知引导文件所在子目录,会直接向 TFTP【根目录】请求 grubx64.efi,
# 因此必须把这些文件链接到 TFTP 根目录,否则报 "Unable to fetch TFTP image: Not Found"。
link_efi_files() {
  local n src
  for n in bootnetx64.efi grubx64.efi mmx64.efi grubnetx64.efi.signed; do
    [[ -e "${TFTP_ROOT}/${n}" ]] && continue
    src="$(find "$TFTP_ROOT" -mindepth 2 -name "$n" -print -quit 2>/dev/null || true)"
    [[ -n "$src" ]] && ln -sf "${src#"${TFTP_ROOT}/"}" "${TFTP_ROOT}/${n}"
  done
  return 0
}

find_efi_binary() {
  local n
  EFI_BIN=""
  link_efi_files
  for n in bootnetx64.efi grubnetx64.efi.signed grubx64.efi; do
    if [[ -e "${TFTP_ROOT}/${n}" ]]; then
      EFI_BIN="${n}"
      return 0
    fi
  done
  warn "netboot 中未找到 UEFI 引导文件,UEFI 客户端将无法启动"
  return 0
}

# ----------------------------- 启动菜单 --------------------------------------
write_boot_menus() {
  local d="debian-installer/amd64"
  local url="http://${SERVER_IP}:${HTTP_PORT}/preseed.cfg"
  local args="auto=true priority=critical url=${url} hostname=${TARGET_HOSTNAME} domain=${TARGET_DOMAIN} interface=auto"

  mkdir -p "${TFTP_ROOT}/pxelinux.cfg" "${TFTP_ROOT}/${d}/grub" "${TFTP_ROOT}/grub"

  # --- BIOS: pxelinux ---
  cat > "${TFTP_ROOT}/pxelinux.cfg/default" <<EOF
say Debian ${DEB_VER} PXE -- type: install | manual | local
default ${DEFAULT_ENTRY}
prompt 1
timeout $((MENU_TIMEOUT * 10))

label install
  kernel ${d}/linux
  append initrd=${d}/initrd.gz ${args} --- quiet

label manual
  kernel ${d}/linux
  append initrd=${d}/initrd.gz --- quiet

label local
  localboot 0
EOF

  # --- UEFI: grub (不同版本 grub 的配置查找位置不同,两处都写) ---
  local grubcfg
  grubcfg="$(cat <<EOF
set timeout=${MENU_TIMEOUT}
set default=${DEFAULT_ENTRY}

menuentry 'Debian ${DEB_VER} Auto Install' --id install {
    linux /${d}/linux ${args} --- quiet
    initrd /${d}/initrd.gz
}

menuentry 'Debian ${DEB_VER} Manual Install' --id manual {
    linux /${d}/linux --- quiet
    initrd /${d}/initrd.gz
}

menuentry 'Boot from local disk' --id local {
    exit
}
EOF
)"
  printf '%s\n' "$grubcfg" > "${TFTP_ROOT}/${d}/grub/grub.cfg"
  printf '%s\n' "$grubcfg" > "${TFTP_ROOT}/grub/grub.cfg"
  chmod -R a+rX "$TFTP_ROOT"
}

# ----------------------------- preseed ---------------------------------------
render_preseed() {
  local tpl="${SCRIPT_DIR}/preseed.cfg"
  [[ -f "$tpl" ]] || die "找不到模板: ${tpl}"
  mkdir -p "$WEB_ROOT"

  # 密码: 环境变量 > 已保存的凭据 > 随机生成
  if [[ -z "$TARGET_PASSWORD" && -f "$CRED_FILE" ]]; then
    TARGET_PASSWORD="$(sed -n 's/^password=//p' "$CRED_FILE" | head -n1 || true)"
  fi
  if [[ -z "$TARGET_PASSWORD" ]]; then
    TARGET_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | cut -c1-14)"
    GENERATED_PW=1
  fi
  local hash
  hash="$(printf '%s' "$TARGET_PASSWORD" | openssl passwd -6 -stdin)"

  umask 077
  printf 'username=%s\npassword=%s\n' "$TARGET_USER" "$TARGET_PASSWORD" > "$CRED_FILE"
  umask 022

  sed \
    -e "s|@@SERVER_IP@@|${SERVER_IP}|g" \
    -e "s|@@HTTP_PORT@@|${HTTP_PORT}|g" \
    -e "s|@@TARGET_HOSTNAME@@|${TARGET_HOSTNAME}|g" \
    -e "s|@@TARGET_DOMAIN@@|${TARGET_DOMAIN}|g" \
    -e "s|@@TARGET_USER@@|${TARGET_USER}|g" \
    -e "s|@@TARGET_DISK@@|${TARGET_DISK}|g" \
    -e "s|@@TIMEZONE@@|${TIMEZONE}|g" \
    -e "s|@@LOCALE@@|${LOCALE}|g" \
    -e "s|@@MIRROR_HOST@@|${DEBIAN_MIRROR}|g" \
    -e "s|@@MIRROR_DIR@@|${MIRROR_DIR}|g" \
    -e "s|@@SUITE@@|${DEB_SUITE}|g" \
    -e "s|@@EXTRA_PACKAGES@@|${EXTRA_PACKAGES}|g" \
    -e "s|@@USER_PASSWORD_CRYPTED@@|${hash}|g" \
    "$tpl" > "${WEB_ROOT}/preseed.cfg"

  if grep -n '@@' "${WEB_ROOT}/preseed.cfg" >&2; then
    die "preseed 中仍有未替换的占位符"
  fi

  if [[ -n "$SSH_PUBKEY_FILE" ]]; then
    [[ -f "$SSH_PUBKEY_FILE" ]] || die "SSH_PUBKEY_FILE 不存在: ${SSH_PUBKEY_FILE}"
    cp "$SSH_PUBKEY_FILE" "${WEB_ROOT}/authorized_keys"
  else
    : > "${WEB_ROOT}/authorized_keys"
  fi
  chmod 755 "$WEB_ROOT"
  chmod 644 "${WEB_ROOT}/preseed.cfg" "${WEB_ROOT}/authorized_keys"
  log "preseed 已生成: ${WEB_ROOT}/preseed.cfg"
}

# ----------------------------- nginx -----------------------------------------
write_nginx() {
  local allow_lines="    allow 127.0.0.1;"
  allow_lines+=$'\n'"    allow ${SERVER_IP};"
  [[ -n "$ALLOW_CIDR" ]] && allow_lines+=$'\n'"    allow ${ALLOW_CIDR};"
  cat > "$NGINX_CONF" <<EOF
# 由 setup-pxe-server.sh 生成
server {
    listen ${HTTP_PORT};
    server_name _;
    root ${WEB_ROOT};
    autoindex off;
${allow_lines}
    deny all;
    access_log /var/log/nginx/debian13-preseed.access.log;
}
EOF
  nginx -t
  systemctl enable nginx >/dev/null 2>&1 || true
  systemctl restart nginx
}

# ----------------------------- dnsmasq ---------------------------------------
write_dnsmasq() {
  if ! grep -Eq '^[[:space:]]*conf-dir=/etc/dnsmasq\.d' /etc/dnsmasq.conf; then
    echo 'conf-dir=/etc/dnsmasq.d/,*.conf' >> /etc/dnsmasq.conf
  fi
  mkdir -p /etc/dnsmasq.d

  {
    cat <<EOF
# 由 setup-pxe-server.sh 生成 —— Debian ${DEB_VER} PXE (MODE=${MODE})
port=0
interface=${IFACE}
bind-interfaces
log-dhcp
enable-tftp
tftp-root=${TFTP_ROOT}
EOF
    if [[ "$MODE" == "proxy" ]]; then
      cat <<EOF

# proxyDHCP: 不分配 IP,只向 PXE 客户端提供引导文件,与现有 DHCP 服务器共存
dhcp-range=${SERVER_IP},proxy
pxe-prompt="Debian ${DEB_VER} network install",3
pxe-service=x86PC,"Debian ${DEB_VER} (BIOS)",pxelinux
EOF
      if [[ -n "$EFI_BIN" ]]; then
        cat <<EOF
pxe-service=X86-64_EFI,"Debian ${DEB_VER} (UEFI)",${EFI_BIN}
pxe-service=BC_EFI,"Debian ${DEB_VER} (UEFI)",${EFI_BIN}
EOF
      fi
    else
      cat <<EOF

# 完整 DHCP 模式: 请确保网络中没有其他 DHCP 服务器
dhcp-authoritative
dhcp-range=${DHCP_START},${DHCP_END},${DHCP_LEASE}
dhcp-option=option:router,${GATEWAY}
dhcp-option=option:dns-server,${DNS_SERVER}
dhcp-match=set:efi64,option:client-arch,7
dhcp-match=set:efi64,option:client-arch,9
dhcp-boot=tag:!efi64,pxelinux.0
EOF
      [[ -n "$EFI_BIN" ]] && echo "dhcp-boot=tag:efi64,${EFI_BIN}"
    fi
  } > "$DNSMASQ_CONF"

  # dnsmasq 软件包的 resolvconf 钩子会把 "nameserver 127.0.0.1" 写进 /etc/resolv.conf,
  # 而本配置 port=0 不提供 DNS,会导致【本机】无法解析域名。
  # 因此让 dnsmasq 忽略 resolvconf,并撤销已写入的记录。
  if [[ -f /etc/default/dnsmasq ]]; then
    if grep -Eq '^[#[:space:]]*IGNORE_RESOLVCONF=' /etc/default/dnsmasq; then
      sed -i -E 's|^[#[:space:]]*IGNORE_RESOLVCONF=.*|IGNORE_RESOLVCONF=yes|' /etc/default/dnsmasq
    else
      echo 'IGNORE_RESOLVCONF=yes' >> /etc/default/dnsmasq
    fi
  fi

  dnsmasq --test -C /etc/dnsmasq.conf
  systemctl enable dnsmasq >/dev/null 2>&1 || true
  systemctl restart dnsmasq

  if command -v resolvconf >/dev/null 2>&1; then
    resolvconf -d lo.dnsmasq >/dev/null 2>&1 || true
    resolvconf -u >/dev/null 2>&1 || true
  fi
}

open_firewall() {
  if command -v ufw >/dev/null 2>&1 && ufw status | grep -q '^Status: active'; then
    log "检测到 ufw 已启用,放行 DHCP/TFTP/HTTP 端口"
    ufw allow 67/udp >/dev/null
    ufw allow 69/udp >/dev/null
    ufw allow 4011/udp >/dev/null
    ufw allow "${HTTP_PORT}/tcp" >/dev/null
  fi
  return 0
}

# ----------------------------- 汇总 / 卸载 ------------------------------------
summary() {
  cat <<EOF

=========================================================================
 Debian ${DEB_VER} (${DEB_SUITE}) 网络自动安装服务器已就绪
-------------------------------------------------------------------------
 模式        : ${MODE}   网卡: ${IFACE}   服务器: ${SERVER_IP}
 TFTP 根目录 : ${TFTP_ROOT}
 preseed URL : http://${SERVER_IP}:${HTTP_PORT}/preseed.cfg
 默认菜单项  : ${DEFAULT_ENTRY} (${MENU_TIMEOUT} 秒后自动进入)
 新系统账户  : ${TARGET_USER}
EOF
  if [[ $GENERATED_PW -eq 1 ]]; then
    echo " 随机密码    : ${TARGET_PASSWORD}   (已保存到 ${CRED_FILE})"
  else
    echo " 密码        : 见 ${CRED_FILE}"
  fi
  cat <<EOF
-------------------------------------------------------------------------
 下一步: 让目标机器/虚拟机从网络(PXE)启动即可自动安装。
 警告  : 自动安装会清空目标磁盘,请勿让不相关的机器从网络启动!
 日志  : journalctl -u dnsmasq -f      tail -f /var/log/nginx/debian13-preseed.access.log
=========================================================================
EOF
}

uninstall() {
  need_root uninstall
  log "移除配置并停止 dnsmasq"
  rm -f "$DNSMASQ_CONF" "$NGINX_CONF"
  systemctl disable --now dnsmasq >/dev/null 2>&1 || true
  systemctl reload nginx >/dev/null 2>&1 || true
  if [[ "${1:-}" == "--purge" ]]; then
    for p in "$TFTP_ROOT" "$WEB_ROOT"; do
      [[ -n "$p" && "$p" != "/" ]] && rm -rf "$p"
    done
    rm -f "$CRED_FILE"
    log "已删除 ${TFTP_ROOT} ${WEB_ROOT}"
  else
    log "文件保留在 ${TFTP_ROOT} 与 ${WEB_ROOT} (加 --purge 可删除)"
  fi
}

# ----------------------------- 入口 ------------------------------------------
case "${1:-install}" in
  install)
    need_root
    validate_mode
    detect_network
    install_packages
    fetch_netboot
    find_efi_binary
    write_boot_menus
    render_preseed
    write_nginx
    write_dnsmasq
    open_firewall
    summary
    ;;
  update)
    need_root update
    validate_mode
    detect_network
    fetch_netboot
    find_efi_binary
    write_boot_menus
    render_preseed
    write_nginx
    write_dnsmasq
    summary
    ;;
  uninstall)
    uninstall "${2:-}"
    ;;
  -h|--help|help)
    usage
    ;;
  *)
    usage
    exit 1
    ;;
esac
