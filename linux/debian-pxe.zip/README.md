# Debian 13 (trixie) 网络自动安装 (PXE + preseed)

## 文件

| 文件 | 作用 |
|---|---|
| `setup-pxe-server.sh` | 一键部署 PXE 服务器:dnsmasq(TFTP/DHCP) + nginx(HTTP) + netboot 镜像 |
| `preseed.cfg` | 应答文件模板,脚本会替换 `@@占位符@@` 后发布到 HTTP |
| `config.env.example` | 参数示例,复制为 `config.env` 即可被脚本读取 |

## 工作流程

```
客户端 PXE 启动 → DHCP/proxyDHCP 给出引导文件 → TFTP 下载 pxelinux(BIOS)/grub(UEFI)
→ 加载 debian-installer 内核与 initrd → HTTP 下载 preseed.cfg
→ 从 Debian 镜像站下载并安装系统 → 自动重启
```

## 快速开始

在一台 Debian/Ubuntu 机器(与目标机器处于同一二层网络)上:

```bash
cp config.env.example config.env     # 按需修改
sudo ./setup-pxe-server.sh
```

脚本结束后会打印 preseed 地址和新系统的用户名/随机密码(也保存在
`/root/debian13-netinstall-credentials.txt`)。然后让目标机器从网络启动即可。

修改参数或 `preseed.cfg` 后:

```bash
sudo ./setup-pxe-server.sh update
```

卸载:`sudo ./setup-pxe-server.sh uninstall [--purge]`

## 两种 DHCP 模式

- **proxy(默认)**:不分配 IP,只给 PXE 客户端提供引导信息,可与路由器自带 DHCP 共存,不会干扰其他设备。
- **dhcp**:本机提供完整 DHCP,需要设置 `DHCP_START` / `DHCP_END`,并确保网络里没有其他 DHCP 服务器。

## 常用参数

| 变量 | 默认值 | 说明 |
|---|---|---|
| `MODE` | `proxy` | `proxy` 或 `dhcp` |
| `DEBIAN_MIRROR` | `deb.debian.org` | netboot 下载与安装所用镜像,国内可用 `mirrors.tuna.tsinghua.edu.cn` |
| `TARGET_HOSTNAME` / `TARGET_DOMAIN` | `debian13` / `localdomain` | 新系统主机名 |
| `TARGET_USER` / `TARGET_PASSWORD` | `admin` / 随机 | root 登录被禁用,使用该用户 + sudo |
| `TARGET_DISK` | 自动 | 例如 `/dev/sda`、`/dev/nvme0n1`,留空选第一块磁盘 |
| `SSH_PUBKEY_FILE` | 空 | 写入新系统用户的 authorized_keys |
| `DEFAULT_ENTRY` / `MENU_TIMEOUT` | `install` / `10` | 启动菜单默认项与超时秒数 |

## 在 PVE 中测试

1. 新建虚拟机,**不挂载 ISO**,网卡接到与 PXE 服务器相同的桥接(如 `vmbr0`)。
2. 引导顺序把 `net0` 放到第一位。
3. BIOS 选 SeaBIOS 可直接使用;选 OVMF(UEFI)时请**关闭 Secure Boot**(不要勾选 Pre-Enroll keys)。
4. 内存建议 ≥ 2 GB,磁盘 ≥ 10 GB,网卡可用 virtio。

## 自定义

- **分区**:默认使用 LVM(卷组 `vg0`),布局为 `/boot` 500MB(ext4,LVM 之外)、`swap` 2GB、`/` 占满剩余空间(ext4)。统一采用 GPT,因此还会多出两个不可省略的小分区:1MB `biosgrub`(BIOS 启动用)和 256MB EFI 分区(UEFI 启动用,BIOS 机器上闲置)。要调整大小,修改 `preseed.cfg` 第 6 节 `expert_recipe` 中对应行的数字(单位 MB,格式为 `最小 优先级 最大`)。
- **静态 IP**:`preseed.cfg` 第 2 节已提供注释好的静态网络配置。
- **软件包**:`EXTRA_PACKAGES` 或 `tasksel/first`(如加入 `xfce-desktop`)。
- 非 x86_64 架构需要下载对应架构的 netboot(`installer-arm64` 等),本方案只覆盖 amd64。

## 安全提示

- 自动安装会**清空目标磁盘且无确认**。默认菜单 10 秒后自动开始安装,请不要在含重要数据的机器上从网络启动;更稳妥可设置 `DEFAULT_ENTRY=local`,需要时再手动选择 `install`。
- preseed 内含密码哈希,脚本已用 nginx `allow/deny` 限制为本机所在网段访问;部署在不可信网络时请进一步限制。
- 新系统密码请在首次登录后修改。

## 排障

```bash
journalctl -u dnsmasq -f                                  # 查看 DHCP/TFTP 请求
tail -f /var/log/nginx/debian13-preseed.access.log        # 客户端是否取到了 preseed
curl http://<服务器IP>:8080/preseed.cfg | head            # HTTP 是否正常
ss -lunp | grep -E ':(67|69|4011)\b'                      # 端口是否监听
```

- 客户端收不到引导信息:检查网卡/网段、防火墙(UDP 67/69/4011、TCP 8080)、虚拟机是否在同一桥接。
- PXE 服务器自己解析不了域名,`/etc/resolv.conf` 里只有 `nameserver 127.0.0.1`:这是 dnsmasq 包的 resolvconf 钩子写入的,而本方案的 dnsmasq 不提供 DNS(`port=0`)。新版脚本会设置 `IGNORE_RESOLVCONF=yes` 并撤销该记录;旧部署重新运行 `sudo ./setup-pxe-server.sh update` 即可。若之后 `/etc/resolv.conf` 里没有真实的 DNS,需要自行补上(例如在 `/etc/network/interfaces` 里加 `dns-nameservers`)。
- UEFI 报 `Fetching Netboot Image grubx64.efi ... Not Found`:shim 会向 TFTP 根目录要 `grubx64.efi`。新版脚本已把 `bootnetx64.efi`、`grubx64.efi` 链接到 TFTP 根目录;旧部署重新运行 `sudo ./setup-pxe-server.sh update` 即可,用 `ls -l /srv/tftp` 确认根目录下有这几个文件。
- UEFI 启动失败:确认已关闭 Secure Boot;可到 `journalctl -u dnsmasq` 里确认客户端请求的文件名。
- 安装器停在某个问题:说明对应项没有被 preseed 覆盖,可在 `preseed.cfg` 中补充(安装时按 Alt+F4 查看日志)。
